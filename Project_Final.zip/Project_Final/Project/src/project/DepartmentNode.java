package project;
//Department Node

// Object used in LinkList

//package project;

public class DepartmentNode {
        private String DepartmentNameInput;
        protected DepartmentNode next;

	

   public DepartmentNode(String DepartmentNameInput){
	
                this.DepartmentNameInput = DepartmentNameInput;
                this.next = null;
    }

    public String getDepartmentNameInput() {
        return DepartmentNameInput;
    }

    public void setDepartmentNameInput(String DepartmentNameInput) {
        this.DepartmentNameInput = DepartmentNameInput;
    }

	
    public DepartmentNode getNext() {
        return next;
    }

    public void setNext(DepartmentNode next) {
        this.next = next;
    } 
}
