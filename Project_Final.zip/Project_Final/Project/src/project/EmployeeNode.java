package project;
//Employee Node

// Object used in LinkList

//package project;

public class EmployeeNode {
        private String LastNameInput;
        private String FirstNameInput;
        private String GenderButton;
        private String SSNInput;
        private String EmployeeIDInput;
	private String PhoneInput;
	private String EmailInput;
	private String HireDateChooser;
	private String EndDateChooser;
	
	
	protected EmployeeNode next;

   public EmployeeNode(String LastNameInput, String FirstNameInput,
   String GenderButton, String SSNInput, String EmployeeIDInput, String PhoneInput, 
	String EmailInput, String HireDateChooser, String EndDateChooser){
                this.LastNameInput = LastNameInput;
                this.FirstNameInput = FirstNameInput;
		this.GenderButton = GenderButton;
                this.SSNInput = SSNInput;
                this.EmployeeIDInput = EmployeeIDInput;
		this.PhoneInput = PhoneInput;
		this.EmailInput = EmailInput;
		this.HireDateChooser = HireDateChooser;
		this.EndDateChooser = EndDateChooser;
		
		
                this.next = null;
    }

    public String getFirstNameInput() {
        return FirstNameInput;
    }

    public void setFirstNameInput(String FirstNameInput) {
        this.FirstNameInput = FirstNameInput;
    }

    public String getLastNameInput() {
        return LastNameInput;
    }

    public void setLastNameInput(String LastNameInput) {
        this.LastNameInput = LastNameInput;
    }
    
    public String getSSNInput() {
        return SSNInput;
    }

    public void setSSNInput(String SSNInput) {
        this.SSNInput = SSNInput;
    }

	
	public String getPhoneInput() {
        return PhoneInput;
    }

    public void setPhoneInput(String PhoneInput) {
        this.PhoneInput = PhoneInput;
    }
	
	public String getEmailInput() {
        return EmailInput;
    }

    public void setEmailInput(String EmailInput) {
        this.EmailInput = EmailInput;
    }
	
	public String getHireDateChooser() {
        return HireDateChooser;
    }

    public void setHireDateChooser(String HireDateChooser) {
        this.HireDateChooser = HireDateChooser;
    }
	
	public String getEndDateChooser() {
        return EndDateChooser;
    }

    public void setEndDateChooser(String EndDateChooser) {
        this.EndDateChooser = EndDateChooser;
    }
	
	public String getGenderButton() {
        return GenderButton;
    }

    public void setGenderButton(String GenderButton) {
        this.GenderButton = GenderButton;
    }
	
	
	public String getEmployeeIDInput() {
        return EmployeeIDInput;
    }

    public void setEmployeeIDInput(String EmployeeIDInput) {
        this.EmployeeIDInput = EmployeeIDInput;
    }
	
	
    public EmployeeNode getNext() {
        return next;
    }

    public void setNext(EmployeeNode next) {
        this.next = next;
    } 
}
