package project;
//Departments LinkedList


// Example List with data

//package project;

public class DepartmentLinkedList {
    
    private DepartmentNode head;
    
    public DepartmentLinkedList() {  
    }

    public DepartmentNode getHead() {
        return head;
    }

    public void setHead(DepartmentNode head) {
       //something add here:
        this.head = head;
    }
    
    public boolean isEmpty() {
        if(head == null) {
            return true;
        } else {
            return false;
        }
    }
    
    public void add(String DepartmentNameInput) {
        if(isEmpty()) {
            head = new DepartmentNode(DepartmentNameInput); 
        } else {
            DepartmentNode current = head;
            while(current.getNext() != null) {
                current = current.getNext();
            } 
            current.setNext(new DepartmentNode(DepartmentNameInput));
        }
    }
        
     public Integer size() {
         Integer size = 0;
         DepartmentNode current = head;
         while (current != null) {
             size++;
             current = current.getNext();
         }
         return size;
     }
}
