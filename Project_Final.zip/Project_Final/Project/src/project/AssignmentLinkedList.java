package project;
//AssignmentLinkedList

// Example List with data

//package project;

public class AssignmentLinkedList {
    
    private AssignmentNode head;
    
    public AssignmentLinkedList() {  
    }

    public AssignmentNode getHead() {
        return head;
    }

    public void setHead(AssignmentNode head) {
       //something add here:
        this.head = head;
    }
    
    public boolean isEmpty() {
        if(head == null) {
            return true;
        } else {
            return false;
        }
    }
    
    public void add(String EmployeeIDSelect, String DepartmentSelect,
   String RankSelect, String AssignmentsBeginDate, String AssignmentsEndDate) {
        if(isEmpty()) {
            head = new AssignmentNode(EmployeeIDSelect, DepartmentSelect,
   RankSelect, AssignmentsBeginDate, AssignmentsEndDate); 
        } else {
            AssignmentNode current = head;
            while(current.getNext() != null) {
                current = current.getNext();
            } 
            current.setNext(new AssignmentNode(EmployeeIDSelect, DepartmentSelect,
   RankSelect, AssignmentsBeginDate, AssignmentsEndDate));
        }
    }
        
     public Integer size() {
         Integer size = 0;
         AssignmentNode current = head;
         while (current != null) {
             size++;
             current = current.getNext();
         }
         return size;
     }
}
