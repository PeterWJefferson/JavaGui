// Names: Peter Jefferson & Dustin McMains

package project;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.FormatterClosedException;
import java.util.Scanner;
import java.util.logging.*;
import java.util.Formatter;
import java.util.Scanner;

public class Project {
   
private static Scanner input;
public static EmployeeLinkedList empList;
public static DepartmentLinkedList deptList;
public static AssignmentLinkedList asgnList;
//?????? day 2 slides?
//public static EmployeeList employeeLinkedList;

public static void main(String[] args) {
// Open text files and create collection lists from add data
System.out.println("Before Read Files");
readfiles();
// Create Form object to present app to user
//new MainForm().setVisible(true);

  MainForm mainform = new MainForm();
      mainform.setVisible(true);
}



// This method reads data from the input files into collections
private static void readfiles() {
readEmployees();
readDepartments();
readAssignments();
// readPaygrade();
}

private static void readEmployees() {
// create Employee List
empList = new EmployeeLinkedList();
// Open Employees.txt file and read each line into an array
openFile("Employees.txt");
while (input.hasNext()) {
    //Added 2 more "input.next()," because I have 11 total employee fields.  The origional code had 9.
empList.add(input.next(), input.next(), input.next(), input.next(), input.next(), input.next(), input.next(), input.next(), input.next());

System.out.printf("%s","test");
}
// Close file
input.close();
}


public static void openFile(String filename) {
try {
input = new Scanner(Paths.get(filename));
}
catch (IOException e) {
System.err.println("Error opening file. Terminating.");
System.out.println( e.getMessage() );
System.exit(1);
}
}


private static void readDepartments() {
// create Department List
deptList = new DepartmentLinkedList();
// Open Employees.txt file and read each line into an array
openFile("Departments.txt");
while (input.hasNext()) {
String dept = input.next();
dept = dept.toUpperCase();
dept.trim();
deptList.add(dept);
}
// Close file
input.close();
}
private static void readAssignments() {
// create Employee List
asgnList = new AssignmentLinkedList();
// Open Employees.txt file and read each line into an array
openFile("Assignments.txt");
while (input.hasNext()) {
asgnList.add(input.next(), input.next(), input.next(), input.next(), input.next());
}
// Close file
input.close();
}
// This method writes data from collections to the files
public static void writefiles() {
    openEmployeesFile();
    addRecordsEmployees();
    closeFile();

    openDepartmentsFile();
    addRecordsDeparments();
    closeFile();
    
    openAssignmentsFile();
    addRecordsAssignments();
    closeFile();
    
    
System.exit(0);

}
private static Formatter output;

//EMPLOYEE WRITE
public static void openEmployeesFile(){
    try{
        output = new Formatter ("Employees.txt");
    }
    catch(SecurityException securityException){
       System.err.println("Write permission denied.");
        System.exit(1);
    } 
    catch(FileNotFoundException fileNotFound){
        System.err.println("File Not Found.");
        System.exit(1);
    }
}

public static void addRecordsEmployees(){
    EmployeeNode eptr = Project.empList.getHead();
    for (int a=0; a < Project.empList.size(); a++){
        try{
            output.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s%n", eptr.getLastNameInput(), eptr.getFirstNameInput(), eptr.getGenderButton(), eptr.getSSNInput(), eptr.getEmployeeIDInput(), eptr.getPhoneInput(), eptr.getEmailInput(), eptr.getHireDateChooser(), eptr.getEndDateChooser());
            eptr = eptr.getNext();
        }
        catch (FormatterClosedException formatterClosedException) {
            System.err.println("Error writing to Employees.txt");
            break;
        }
    }
}


//WRITE DEPARTMENTS
public static void openDepartmentsFile(){
    try{
        output = new Formatter ("Departments.txt");
    }
    catch(SecurityException securityException){
       System.err.println("Write permission denied.");
        System.exit(1);
    } 
    catch(FileNotFoundException fileNotFound){
        System.err.println("File Not Found.");
        System.exit(1);
    }
}

public static void addRecordsDeparments(){
    DepartmentNode dptr = Project.deptList.getHead();
    for (int a=0; a < Project.deptList.size(); a++){
        try{
            output.format("%s%n", dptr.getDepartmentNameInput());
            dptr = dptr.getNext();
        }
        catch (FormatterClosedException formatterClosedException) {
            System.err.println("Error writing to Departments.txt");
            break;
        }
    }
}


//WRITE ASSIGNMENTS
public static void openAssignmentsFile(){
    try{
        output = new Formatter ("Assignments.txt");
    }
    catch(SecurityException securityException){
       System.err.println("Write permission denied.");
        System.exit(1);
    } 
    catch(FileNotFoundException fileNotFound){
        System.err.println("File Not Found.");
        System.exit(1);
    }
}

public static void addRecordsAssignments(){
    AssignmentNode aptr = Project.asgnList.getHead();
    for (int a=0; a < Project.asgnList.size(); a++){
        try{
            output.format("%s\t%s\t%s\t%s\t%s%n", aptr.getEmployeeIDSelect(), aptr.getDepartmentSelect(), aptr.getRankSelect(), aptr.getAssignmentsBeginDate(), aptr.getAssignmentsEndDate());
            aptr = aptr.getNext();
        }
        catch (FormatterClosedException formatterClosedException) {
            System.err.println("Error writing to Assignments.txt");
            break;
        }
    }
}

//CLOSE METHOD
public static void closeFile(){
    if(output==null){
        output.close();
    }
}

}