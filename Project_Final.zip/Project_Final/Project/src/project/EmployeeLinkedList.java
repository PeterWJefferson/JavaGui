package project;

// Example List with data

//package project;

public class EmployeeLinkedList {
    
    private EmployeeNode head;
    
    public EmployeeLinkedList() {  
    }

    public EmployeeNode getHead() {
        return head;
    }

    public void setHead(EmployeeNode head) {
       //something add here:
        this.head = head;
    }
    
    public boolean isEmpty() {
        if(head == null) {
            return true;
        } else {
            return false;
        }
    }
    
    public void add(String LastNameInput, String FirstNameInput,
   String GenderButton, String SSNInput, String EmployeeIDInput, String PhoneInput, 
	String EmailInput, String HireDateChooser, String EndDateChooser) {
        if(isEmpty()) {
            head = new EmployeeNode(LastNameInput, FirstNameInput,
   GenderButton, SSNInput, EmployeeIDInput, PhoneInput, 
	EmailInput, HireDateChooser, EndDateChooser); 
        } else {
            EmployeeNode current = head;
            while(current.getNext() != null) {
                current = current.getNext();
            } 
            current.setNext(new EmployeeNode(LastNameInput, FirstNameInput,
   GenderButton, SSNInput, EmployeeIDInput, PhoneInput, 
	EmailInput, HireDateChooser, EndDateChooser));
        }
    }
        
     public Integer size() {
         Integer size = 0;
         EmployeeNode current = head;
         while (current != null) {
             size++;
             current = current.getNext();
         }
         return size;
     }
}
