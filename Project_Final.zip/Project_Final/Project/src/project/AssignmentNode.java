package project;
//AssignmentNode

//EmployeeIDSelect, DepartmentSelect,
   //RankSelect, AssignmentsBeginDate, AssignmentsEndDate

public class AssignmentNode {
    private String EmployeeIDSelect;
    private String DepartmentSelect;
    private String RankSelect;
    private String AssignmentsBeginDate;
    private String AssignmentsEndDate;
    protected AssignmentNode next;
	

   public AssignmentNode(String EmployeeIDSelect, String DepartmentSelect, String RankSelect, 
                           String AssignmentsBeginDate, String AssignmentsEndDate){
	
        this.EmployeeIDSelect = EmployeeIDSelect;
	this.DepartmentSelect = DepartmentSelect;
        this.RankSelect = RankSelect;
	this.AssignmentsBeginDate = AssignmentsBeginDate;
	this.AssignmentsEndDate = AssignmentsEndDate;
        this.next = null;
    }

    public String getEmployeeIDSelect() {
        return EmployeeIDSelect;
    }

    public void setEmployeeIDSelect(String EmployeeIDSelect) {
        this.EmployeeIDSelect = EmployeeIDSelect;
    }

    public String getDepartmentSelect() {
        return DepartmentSelect;
    }

    public void setDepartmentSelect(String DepartmentSelect) {
        this.DepartmentSelect = DepartmentSelect;
    }
    
    public String getRankSelect() {
        return RankSelect;
    }

    public void setRankSelect(String RankSelect) {
        this.RankSelect = RankSelect;
    }

	
	public String getAssignmentsBeginDate() {
        return AssignmentsBeginDate;
    }

    public void setAssignmentsBeginDate(String AssignmentsBeginDate) {
        this.AssignmentsBeginDate = AssignmentsBeginDate;
    }
	
	public String getAssignmentsEndDate() {
        return AssignmentsEndDate;
    }

    public void setAssignmentsEndDate(String AssignmentsEndDate) {
        this.AssignmentsEndDate = AssignmentsEndDate;
    }
	
    public AssignmentNode getNext() {
        return next;
    }

    public void setNext(AssignmentNode next) {
        this.next = next;
    } 
}
